import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:8070/api/v1';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const accessToken = this.authService.getCurrentUser();

    // Set the Authorization header with the access token
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    });

  }
  
  getMyLeaveRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/leave/my-leave-requests`, { headers });
  }
  
  getMyLoanRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/loan/my-loan-requests`, { headers });
  }
  
  getMyDocumentRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/document/my-document-requests`, { headers });
  }
  
  getMyAuthRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/auth/my-auth-requests`, { headers });
  }
  
  getMyPersonalSituationRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/personal/my-personal-situation-requests`, { headers });
  }
  
  login(email: string, password: string): Observable<any> {
    const loginData = { email, password };
    return this.http.post<any>(`${this.baseUrl}/auth/login`, loginData);
  }

  getAllUsers(): Observable<User[]> {
    const headers = this.getHeaders();
    return this.http.get<User[]>(`${this.baseUrl}/requests/users`, { headers });
  }

  getHRApprovedRequestsPendingAdmin() {
    return this.http.get<any[]>(`${this.baseUrl}/hr-approved`);
  }

  approveLeaveRequestByHR(requestId: number, response: string): Observable<any> {
    const headers = this.getHeaders();
    const body = { response };
    return this.http.put<any>(`${this.baseUrl}/requests/leave/${requestId}/approve-hr`, body, { headers });
  }
  
  denyLeaveRequestByHR(requestId: number, response: string): Observable<any> {
    const headers = this.getHeaders();
    const body = { response };
    return this.http.put<any>(`${this.baseUrl}/requests/leave/${requestId}/deny-hr`, body, { headers });
  }


  createLeaveRequest(leaveRequestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/leave/send-req`, leaveRequestData, { headers });
  }

  createLoanRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/loan/send-req`, requestData, { headers });
  }

  createDocumentRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/document/send-req`, requestData, { headers });
  }

  getHRApprovedLeaveRequestsPendingAdmin(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/leave/hr-approved`, { headers });
  }

  createAuthRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/auth/send-req`, requestData, { headers });
  }

  createPersonalSituationRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/personal/send-req`, requestData, { headers });
  }

  getMyRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/my-requests`, { headers });
  }

  getAllRequestsHR(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/Hr_req`, { headers });
  }

  getPendingRequestsHR(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/RH-pending-requests`, { headers });
  }

  // New methods for Admin requests
  getAdminRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/Admin_req`, { headers });
  }

  getAdminPendingRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/Admin-pending-requests`, { headers });
  }

  getUserProfile(): Observable<any> {
    const headers = this.getHeaders();
    return this.http.get<any>(`${this.baseUrl}/users/profile`, { headers });
  }
  getUserProfile1(id: number): Observable<User> {
    const headers = this.getHeaders();
    return this.http.get<User>(`${this.baseUrl}/users/${id}`,{ headers });
  }
  // HR Requests
  getLoanRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/loan-requests`, { headers });
  }

  getPendingLoanRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/loan-requests/pending`, { headers });
  }

  getPersonalSituationRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/personal-situation-requests`, { headers });
  }

  getPendingPersonalSituationRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/personal-situation-requests/pending`, { headers });
  }

  getDocumentRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/document-requests`, { headers });
  }

  getPendingDocumentRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/document-requests/pending`, { headers });
  }

  getLeaveRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/admin/leave-requests`, { headers });
  }

  getPendingLeaveRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/hr/leave-requests/pending`, { headers });
  }

  // Admin Requests

  updateLeaveRequestStatusAndResponse(requestId: number, isApproved: boolean, response?: string): Observable<any> {
  const headers = this.getHeaders();
  const params = new HttpParams().set('isApproved', isApproved.toString());
  if (response) {
    params.set('response', response);
  }
  return this.http.put<any>(`${this.baseUrl}/requests/leave/${requestId}/approve-admin`, null, { headers, params });
}

  getHrApprovedLeaveRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/leave/hr-approved`, { headers });
  }

  getAuthRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/admin/auth-requests`, { headers });
  }

  getPendingAuthRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/admin/auth-requests/pending`, { headers });
  }

  getAdminLeaveRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/admin/leave-requests`, { headers });
  }

  getPendingAdminLeaveRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/admin/leave-requests/pending`, { headers });
  }

  updateRequestStatus(requestId: number, newStatus: string, response: string): Observable<any> {
    const headers = this.getHeaders();
    const params = new HttpParams().set('newStatus', newStatus).set('response', response);
    return this.http.put<any>(`${this.baseUrl}/requests/${requestId}/status`, null, { headers, params });
  }

  updatePersonalSituationRequestStatusAndResponse(requestId: number, newStatus: string, response: string): Observable<any> {
    const headers = this.getHeaders();
    const params = new HttpParams().set('newStatus', newStatus).set('response', response);
    return this.http.put<any>(`${this.baseUrl}/requests/personal/${requestId}/status`, null, { headers, params });
  }

  updateLoanRequestStatusAndResponse(requestId: number, newStatus: string, response: string): Observable<any> {
    const headers = this.getHeaders();
    const params = new HttpParams().set('newStatus', newStatus).set('response', response);
    return this.http.put<any>(`${this.baseUrl}/requests/loan/${requestId}/status`, null, { headers, params });
  }

  updateDocumentRequestStatusAndResponse(requestId: number, newStatus: string, response: string): Observable<any> {
    const headers = this.getHeaders();
    const params = new HttpParams().set('newStatus', newStatus).set('response', response);
    return this.http.put<any>(`${this.baseUrl}/requests/document/${requestId}/status`, null, { headers, params });
  }

  updateAuthRequestStatusAndResponse(requestId: number, newStatus: string, response: string): Observable<any> {
    const headers = this.getHeaders();
    const params = new HttpParams().set('newStatus', newStatus).set('response', response);
    return this.http.put<any>(`${this.baseUrl}/requests/auth/${requestId}/status`, null, { headers, params });
  }

  getPendingLoanRequestsCount(): Observable<number> {
    const headers = this.getHeaders();
    return this.http.get<number>(`${this.baseUrl}/requests/hr/loan-requests/pending/count`, { headers });
  }

  getPendingPersonalSituationRequestsCount(): Observable<number> {
    const headers = this.getHeaders();
    return this.http.get<number>(`${this.baseUrl}/requests/hr/personal-situation-requests/pending/count`, { headers });
  }

  getPendingDocumentRequestsCount(): Observable<number> {
    const headers = this.getHeaders();
    return this.http.get<number>(`${this.baseUrl}/requests/hr/document-requests/pending/count`, { headers });
  }

  getPendingLeaveRequestsCount(): Observable<number> {
    const headers = this.getHeaders();
    return this.http.get<number>(`${this.baseUrl}/requests/admin/leave-requests/pending/count`, { headers });
  }

  getPendingAuthRequestsCount(): Observable<number> {
    const headers = this.getHeaders();
    return this.http.get<number>(`${this.baseUrl}/requests/admin/auth-requests/pending/count`, { headers });
  }

  // Attendance API methods
  checkIn(userId: number): Observable<Attendance> {
    const headers = this.getHeaders();
    return this.http.post<Attendance>(`${this.baseUrl}/attendance/check-in`, null, { headers, params: { userId: userId.toString() } });
  }

  checkOut(userId: number): Observable<Attendance> {
    const headers = this.getHeaders();
    return this.http.post<Attendance>(`${this.baseUrl}/attendance/check-out`, null, { headers, params: { userId: userId.toString() } });
  }

  getUserAttendance(userId: number): Observable<Attendance[]> {
    const headers = this.getHeaders();
    return this.http.get<Attendance[]>(`${this.baseUrl}/attendance/user/${userId}`, { headers });
  }
  
}

interface User {
  id: number;
  fullName: string;
  email: string;
}

interface Attendance {
  id: number;
  user: User;
  date: string;
  checkInTime: string;
  checkOutTime: string;
}
