import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './app-attendance.component.html',
  styleUrls: ['./app-attendance.component.scss']
})
export class AttendanceComponent implements OnInit {
  userId: number;
  attendanceRecords: Attendance[] = [];

  constructor(private apiService: ApiService) {
    // Replace with actual user ID retrieval logic
    this.userId = 1; 
  }

  ngOnInit(): void {
    this.fetchAttendance();
  }

  checkIn(): void {
    this.apiService.checkIn(this.userId).subscribe(
      attendance => {
        console.log('Check-in successful:', attendance);
        this.fetchAttendance(); // Refresh attendance records
      },
      error => {
        console.error('Error during check-in:', error);
      }
    );
  }

  checkOut(): void {
    this.apiService.checkOut(this.userId).subscribe(
      attendance => {
        console.log('Check-out successful:', attendance);
        this.fetchAttendance(); // Refresh attendance records
      },
      error => {
        console.error('Error during check-out:', error);
      }
    );
  }

  fetchAttendance(): void {
    this.apiService.getUserAttendance(this.userId).subscribe(
      attendanceRecords => {
        this.attendanceRecords = attendanceRecords;
      },
      error => {
        console.error('Error fetching attendance records:', error);
      }
    );
  }
}

interface Attendance {
  id: number;
  user: User;
  date: string;
  checkInTime: string;
  checkOutTime: string;
}

interface User {
  id: number;
  fullName: string;
  email: string;
  // Add other user properties as needed
}
