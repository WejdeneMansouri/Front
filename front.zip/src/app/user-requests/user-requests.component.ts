import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-user-requests',
  templateUrl: './user-requests.component.html',
  styleUrls: ['./user-requests.component.scss']
})
export class UserRequestsComponent implements OnInit {
  leaveRequests: any[] = [];
  loanRequests: any[] = [];
  documentRequests: any[] = [];
  authRequests: any[] = [];
  personalSituationRequests: any[] = [];
  hasRequests: boolean = false;


  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.fetchLeaveRequests();
    this.fetchLoanRequests();
    this.fetchDocumentRequests();
    this.fetchAuthRequests();
    this.fetchPersonalSituationRequests();
  }
  checkForRequests(): void {
    this.hasRequests = this.leaveRequests.length > 0 ||
                      this.loanRequests.length > 0 ||
                      this.documentRequests.length > 0 ||
                      this.authRequests.length > 0 ||
                      this.personalSituationRequests.length > 0;
  }
  fetchLeaveRequests(): void {
    this.apiService.getMyLeaveRequests().subscribe(
      (data: any[]) => {
        this.leaveRequests = data;
        this.checkForRequests();
      },
      (error) => {
        console.error('Error fetching leave requests:', error);
      }
    );
  }

  fetchLoanRequests(): void {
    this.apiService.getMyLoanRequests().subscribe(
      (data: any[]) => {
        this.loanRequests = data;
        this.checkForRequests();
      },
      (error) => {
        console.error('Error fetching loan requests:', error);
      }
    );
  }

  fetchDocumentRequests(): void {
    this.apiService.getMyDocumentRequests().subscribe(
      (data: any[]) => {
        this.documentRequests = data;
        this.checkForRequests();
      },
      (error) => {
        console.error('Error fetching document requests:', error);
      }
    );
  }

  fetchAuthRequests(): void {
    this.apiService.getMyAuthRequests().subscribe(
      (data: any[]) => {
        this.authRequests = data;
        this.checkForRequests();
      },
      (error) => {
        console.error('Error fetching auth requests:', error);
      }
    );
  }

  fetchPersonalSituationRequests(): void {
    this.apiService.getMyPersonalSituationRequests().subscribe(
      (data: any[]) => {
        this.personalSituationRequests = data;
        this.checkForRequests();
      },
      (error) => {
        console.error('Error fetching personal situation requests:', error);
      }
    );
  }
}
